#include<ros/ros.h>
#include<iostream>
#include"yhs_can_control.h"

using namespace std;

int main(int argc, char ** argv)
{
    ros::init(argc, argv, "yhs_fr07_control_node");  //初始化ros
    ros::NodeHandle n; //定义ros句柄
    ros::Publisher pub = n.advertise<yhs_can_msgs::ctrl_cmd>("ctrl_cmd",5);
    //geometry_msgs::Twist vel;
    return 0;
}

